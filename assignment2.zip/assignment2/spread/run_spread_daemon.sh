#!/bin/sh 
spread -l y -c spread.conf

package example.gossip;

public enum MessageType {
	SHUFFLE_REQUEST, SHUFFLE_REPLY, SHUFFLE_REJECTED
}
